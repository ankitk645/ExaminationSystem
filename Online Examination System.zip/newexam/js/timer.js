window.onload=function(){
		var x = 10;
		var y = document.getElementById("timer");
		setInterval(function(){
		 if( x<=11 && x>=1)
		 {
			x--;
			y.innerHTML= ''+x+'';	
			
			if(x==1)
			{
			 x=11;
			}
		}
		
		}, 1000);
    var auto_refresh = setInterval(function() { submitform(); }, 10000);
	function submitform()
	 {
           alert("quiz is being submited");
		   document.getElementById("exam").submit();
	 }
	 
};